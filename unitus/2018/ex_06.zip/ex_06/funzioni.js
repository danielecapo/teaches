function map (fn, list) {
    var ret = [];
    for (var i = 0; i < list.length; i++) {
	ret [i] = fn (list[i]);
    }
    return ret;
}

function reduce (fn, initial, list) {
    var ret = initial;
    for (var i = 0; i < list.length; i++) {
	ret = fn (ret, list [i]);
    }
    return ret;
}

function foreach (fn, list) {
    for (var i = 0; i < list.length; i++) {
	fn (list [i]);
    }
}

function numero_casuale(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}


function pulisci () {
    var target = document.getElementById ("target");
     while (target.firstChild) {
       target.removeChild(target.firstChild);
   }
}

function applica_sfondo_casuale (elemento) {
    var colore = "hsl("+numero_casuale(0, 360)+","+numero_casuale (0,100)+"%,"+numero_casuale (60,100)+"%)";
    elemento.style.backgroundColor = colore;
    return elemento;
}



function span (oggetto) {
    var span = document.createElement ('span');
    if (typeof(oggetto) ==  'object') {
	span.appendChild (oggetto);
    }
    else {
	span.appendChild (document.createTextNode (oggetto));
    }
    return span;
}

function p (oggetto) {
    var p = document.createElement ('p');
    if (typeof(oggetto) ==  'object') {
	p.appendChild (oggetto);
    }
    else {
	p.appendChild (document.createTextNode (oggetto));
    }
    return p;
}


function div (oggetto) {
    var div = document.createElement ('div');
    if (typeof(oggetto) ==  'object') {
	div.appendChild (oggetto);
    }
    else {
	div.appendChild (document.createTextNode (oggetto));
    }
    return div;
}

function img (file) {
    var img = document.createElement ('img');
    img.setAttribute ("src", file);
    return img;
}

function scrivi (oggetto) {
    var target = document.getElementById ("target");

    if (typeof(oggetto) ==  'object') {
	target.appendChild (oggetto);
    }
    else {
	target.appendChild (document.createTextNode (oggetto.toString()));
    }
}

/*
function stampa_poesia (versi, colori) {
    var target = document.getElementById ("target");
    pulisci ();

    foreach (function (verso) {
	var div = document.createElement ('div');
	var p = document.createElement ('p');
	applica_sfondo_casuale (div, colori);
	p.appendChild (document.createTextNode (verso));
	div.appendChild (p);
	target.appendChild (div);
    }, versi);
}
*/

function scegli_tra (list) {
    return list [numero_casuale(0, list.length - 1)];
}



var sfondi =  ["#88d9ff", "#33c6f4", "#feda00", "#f37544", "#c2e5f9",
	      "#fdd8c0", "#a365ae", "hsl(0,20%,100%)", "hsl(20, 30%, 70%)",
	      "hsl(30, 30%, 80%)", "hsl(40, 50%, 80%)", "hsl(50, 60%, 90%)",
	       "hsl(60, 70%, 80%)"];

var dati = [["Il cavallo veloce", "Il mulo accorato", "Il gatto repentino", "Il topo manipolatore", "Lo spazzacamino astratto", "Il monastero fumante", "Un rapido sorriso", "Uno sguardo infuocato", "La filosofa muta", "Una rosticceria cubista"],
	    ["ripone nell'antro", "assolve dal fuoco", "sostiene nel buio", "sorregge al calore", "seppellisce con la mente", "insinua nel rumore", "abbandona nel deserto"],
	    ["come un bersaglio", "dall'alto della torre", "immantinente", "dalla finestra cieca", "nel fitto del bosco", "dai misteri ossidati", "nell'ufficio della ministra"],
	    ["la storia dei logaritmi", "la virtù marinara", "la sostanza mascherata", "la fonte disseccata", "la repentina sorte", ],
	    ["cantando come Toto Cutugno", "sostenendo il peso di Justin Bieber", "salmodiando le canzoni dei Ricchi e Poveri", "ossessionando i vicini dei Pooh", "localizzando il terrore di Britney Spears", "definendo gli accordi dei Sex Pistols", "rendendo omaggio ai cori russi"]];


var versi = ["nel mezzo del cammin di nostra vita", "mi ritrovai per una selva oscura", "che la diritta via era smarrita"];

function animazione () {
    return setInterval (function () {stampa_poesia (map (scegli_tra, dati), sfondi);}, 500);
}
