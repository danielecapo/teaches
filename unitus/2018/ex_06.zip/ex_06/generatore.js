function vai () {
   /* scrivere qui sotto */
   var A = ["A1.png", "A2.png", "A3.png"];
   var B = ["B1.png", "B2.png", "B3.png"];
   var C = ["C1.png", "C2.png", "C3.png"];
   var parti = [A, B , C];

    function combina (parti) {
	     return map (scegli_tra, parti);
    }

    function scrivifigura (frase) {
	     foreach (scrivi, map (img, frase));
    }
    pulisci();

    scrivifigura (combina (parti));

}


/* non modificare qui sotto */

window.onload = function () {
    var esegui = document.getElementById ('esegui');
    esegui.onclick = function () { vai();
				   return false;};

    vai();
}
